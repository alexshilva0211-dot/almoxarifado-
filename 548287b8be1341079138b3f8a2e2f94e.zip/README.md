# Controle de Ferramentas, Materiais e EPIs

Aplicativo web para almoxarifado de obra: ferramentas, materiais e EPIs.

## Publicar no GitHub

1. Crie um repositório no GitHub.
2. Envie os arquivos desta pasta para a raiz do repositório.
3. O arquivo principal é `index.html`.

## Hospedar no Netlify

1. No Netlify, escolha **Add new site > Import an existing project > GitHub**.
2. Selecione o repositório.
3. Deixe **Build command** vazio.
4. Em **Publish directory**, informe `.`
5. Clique em **Deploy site**.

Os dados são salvos no navegador de cada dispositivo (`localStorage`).
